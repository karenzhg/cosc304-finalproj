<?php
	$username = "SA";
	$password = "304#sa#pw";
	$database = "orders";
	$server = "cosc304_sqlserver";
	$connectionInfo = array( "Database"=>$database, "UID"=>$username, "PWD"=>$password, "CharacterSet" => "UTF-8", "TrustServerCertificate"=>"yes");
?>